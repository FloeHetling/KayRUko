<?php
//=======================================
//###################################
// Kayako Web Solutions
//
// Source Copyright 2001-2004 Kayako Singapore Pte. Ltd.
// Unauthorized reproduction is not allowed
// License Number: $%LICENSE%$
// $Author$ ($Date$)
// $RCSfile$ : $Revision$
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
//                   www.kayako.com
//###################################
//=======================================


$__LANG = array (
	// Potentialy unused phrases in staffmenu.php
	'settings' => 'Настройки',
	'worksched' => 'Work Schedule',
	'changepass' => 'Change Password',
	'snewtickets' => 'New Tickets',
	'sadvancedsearch' => 'Advanced Search',
	'squicksearch' => 'Quick Search',
	'stidlookup' => 'Ticket ID Lookup',
	'screatorreplier' => 'Creator/Replier',
);

?>
