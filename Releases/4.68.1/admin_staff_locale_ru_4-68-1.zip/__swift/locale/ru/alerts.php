<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Floe Hetling
 *
 * @package		SWIFT
 * @copyright	no data 
 * @license		no data 
 * @link		https://github.com/FloeHetling/KayRUko
 *
 * ###############################################
 */

$__LANG = array (

);
?>